package com.dn.exceptions;

public class ExceptionToTest extends Exception {
	public ExceptionToTest(String msg) {
		super(msg);
	}
}