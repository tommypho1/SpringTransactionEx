package com.dn.exceptions;

public class InValidCourseId extends Exception {
	public InValidCourseId(String msg) {
		super(msg);
	}
}