package com.dn.dao;

import com.dn.domain.Student;

public interface StudentDAO {
	public Student insertStudent(Student student);

}
