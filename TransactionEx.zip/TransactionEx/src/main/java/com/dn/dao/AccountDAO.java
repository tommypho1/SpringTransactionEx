package com.dn.dao;

import com.dn.domain.Account;


public interface AccountDAO {
	public Account insertAccount(Account account);
}
