package com.dn.dao;

import com.dn.domain.StudentCourse;

public interface StudentCourseDAO {
	public StudentCourse insertStudentCourse(StudentCourse studentCourse);
}
