package com.dn.dao;

import com.dn.domain.Course;

public interface CourseDAO {
	public Course insertCourse(Course course);
}
