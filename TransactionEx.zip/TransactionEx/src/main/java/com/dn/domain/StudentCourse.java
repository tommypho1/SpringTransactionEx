package com.dn.domain;

public class StudentCourse {
	private int numCourse;
	private int studentId;
	private String courseId;
	public String getCourseId() {
		return courseId;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	public int getNumCourse() {
		return numCourse;
	}
	public void setNumCourse(int numCourse) {
		this.numCourse = numCourse;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	
	
}
